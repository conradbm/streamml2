# Setup streamml db
python setup_files/database_setup.py
python setup_files/database_engine_setup.py
python database_connection.py
